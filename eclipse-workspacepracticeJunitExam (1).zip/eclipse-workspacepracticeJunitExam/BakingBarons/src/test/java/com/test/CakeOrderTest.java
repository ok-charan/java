package com.test;

import com.test.Main;
import com.exception.InvalidCakeOrderException;
import com.model.CakeOrder;
import com.util.CakeOrderUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CakeOrderTest {
	
	private static List<CakeOrder> cakeOrderList;
	private static CakeOrderUtil uObj;
	
	@BeforeAll
	public static void setUp() throws Exception {
		//Create few objects for CakeOrder class and add to a list
		//Set that list to the CakeOrderList using the setCakeOrderList method in CakeOrderUtil class
		List<CakeOrder> cakeOrderList = new ArrayList<CakeOrder>();
		cakeOrderList.add(new CakeOrder("1","ChocolateCake","Normal",2,100.0,"Delivered"));
		cakeOrderList.add(new CakeOrder("2","CoolCake","Freshcream",4,300.0,"Pending"));
	    uObj = new CakeOrderUtil();
	    uObj.setCakeOrderList(cakeOrderList);
	}
	
	//Test the validateCakeType method when the cakeType is Normal
	@Test
	public void test11ValidateCakeTypeWhenNormal() throws InvalidCakeOrderException{
		
        //Fill the code 
		assertTrue(uObj.validateCakeType("Normal"));
	}
	
	//Test the validateCakeType method when the cakeType is FreshCream
	@Test
	public void test12ValidateCakeTypeWhenFreshCream() throws InvalidCakeOrderException{
		
		 //Fill the code 
		assertTrue(uObj.validateCakeType("FreshCream"));
	}
	
    //Test the validateCakeType method when the cakeType is invalid
	@Test
	public void test13ValidateCakeTypeWhenInvalid()throws InvalidCakeOrderException{
		//Fill the code 
		assertThrows(InvalidCakeOrderException.class,()->uObj.validateCakeType(" "));
		
		
	}
	
	//Test the viewCakeOrderByOrderId method when the orderId is valid
	@Test
	public void test14ViewCakeOrderByOrderIdWhenValid() throws InvalidCakeOrderException {
        //Fill the code 
		assertEquals("2",uObj.viewCakeOrderByOrderId("2").getOrderId());
	}

	//Test the viewCakeOrderByOrderId method when the orderId is invalid
	@Test
	public void test15ViewCakeOrderByOrderIdWhenInvalid() {
		 //Fill the code
		assertThrows(InvalidCakeOrderException.class,()->uObj.viewCakeOrderByOrderId(""));
		
		 
	}

	 //Test the viewCakeOrderByCakeType method
	@Test
	 public void test16ViewCakeOrderByCakeType() throws InvalidCakeOrderException {
		 //Fill the code
//		List<CakeOrder> list=uObj.viewCakeOrderByCakeType("");
//		System.out.println(list);
//		assertEquals("Normal",uObj.viewCakeOrderByCakeType("Normal").get(0).getCakeType());
		List<CakeOrder> li=uObj.viewCakeOrderByCakeType("Normal");
		System.out.println(li);
		assertEquals("Normal",li.get(0).getCakeType());
	 }
	 
	 //Test the viewCakeOrderByCakeTypeWise method
	@Test
	 public void test17ViewCakeOrderByCakeTypeWise() throws InvalidCakeOrderException {
		  //Fill the code
		Map<String,List<CakeOrder>> mp=uObj.viewCakeOrderByCakeTypeWise();
		System.out.println(mp.toString());
		assertEquals("Normal",mp.get("Normal").get(0).getCakeType());
	 }

	 //Test the countTotalCakeOrderForEachStatus method
	@Test
	 public void test18CountTotalCakeOrderForEachStatus() throws InvalidCakeOrderException{
		  //Fill the code
		Map<String,Integer> mp=uObj.countTotalCakeOrderForEachStatus();
		System.out.println(mp.toString());
		assertEquals(1,mp.get("Delivered"));
	 }

	 //Test the viewCakeOrderByCakeType method when the list is empty
	@Test
	 public void test19ViewCakeOrderByCakeTypeForEmptyList() {
		  //Fill the code
		CakeOrderUtil cake=new CakeOrderUtil();
		assertThrows(InvalidCakeOrderException.class,()->cake.viewCakeOrderByCakeTypeWise());
		
		
		
		
		
	 }	 	  	  	 		     	   	      	 	
	 
	 //Test the viewCakeOrderByCakeTypeWise method when the list is empty
	 @Test
	 public void test20ViewCakeOrderByCakeTypeWiseForEmptyList() {
		 //Fill the code
		 CakeOrderUtil cake=new CakeOrderUtil();
		 assertThrows(InvalidCakeOrderException.class,()->cake.viewCakeOrderByCakeTypeWise());
	 }

	//Test the countTotalCakeOrderForEachStatus method when the list is empty
	 @Test
	public void test21CountTotalCakeOrderForEachStatusForEmptyList() {
	    //Fill the code
		 CakeOrderUtil cake=new CakeOrderUtil();
		 assertThrows(InvalidCakeOrderException.class,()->cake.countTotalCakeOrderForEachStatus());
	}
	 
}
	 	  	  	 		     	   	      	 