package com.model;

public class CakeOrder {
	private String orderId;
	private String cakeName;
	private String cakeType;
	private double quantity;
	private double price;
	private String status;
	
	public CakeOrder(String orderId, String cakeName, String cakeType, double quantity, double price, String status) {
		super();
		this.orderId = orderId;
		this.cakeName = cakeName;
		this.cakeType = cakeType;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
	}
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCakeName() {
		return cakeName;
	}
	public void setCakeName(String cakeName) {
		this.cakeName = cakeName;
	}
	public String getCakeType() {
		return cakeType;
	}
	public void setCakeType(String cakeType) {
		this.cakeType = cakeType;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
