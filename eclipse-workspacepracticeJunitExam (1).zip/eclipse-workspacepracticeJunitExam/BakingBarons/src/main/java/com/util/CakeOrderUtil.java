package com.util;

import com.exception.InvalidCakeOrderException;
import com.model.CakeOrder;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CakeOrderUtil {
	List<CakeOrder> cakeOrderList = new ArrayList<CakeOrder>();

	public List<CakeOrder> getCakeOrderList() {
		return cakeOrderList;
	}

	public void setCakeOrderList(List<CakeOrder> cakeOrderList) {
		this.cakeOrderList = cakeOrderList;
	}
	
	public boolean validateCakeType(String cakeType) throws InvalidCakeOrderException{
		if(cakeType.equalsIgnoreCase("freshcream") || cakeType.equalsIgnoreCase("normal"))
			return true;
		else
			throw new InvalidCakeOrderException("cakeType is invalid");
	}
	
	public CakeOrder viewCakeOrderByOrderId(String orderId) throws InvalidCakeOrderException{
		if(cakeOrderList.size() == 0)
			throw new InvalidCakeOrderException("List is empty");
		else
		{
			for(CakeOrder ord : cakeOrderList)
			{
				if(ord.getOrderId().equals(orderId))
					return ord;
			}
			throw new InvalidCakeOrderException("Order Id is invalid");
		}
	}
	
	public List<CakeOrder> viewCakeOrderByCakeType(String cakeType) throws InvalidCakeOrderException{
		if(cakeOrderList.size() == 0)
			throw new InvalidCakeOrderException("List is empty");
		else
		{
			List<CakeOrder> result = new ArrayList<CakeOrder>();
			for(CakeOrder ord : cakeOrderList)
			{
				if(ord.getCakeType().equalsIgnoreCase(cakeType))
					result.add(ord);
			}
			return result;
		}
	}
	
	public Map<String,List<CakeOrder>> viewCakeOrderByCakeTypeWise() throws InvalidCakeOrderException{
		if(cakeOrderList.size() == 0)
			throw new InvalidCakeOrderException("List is empty");
		else
		{
			Map<String,List<CakeOrder>> result = new LinkedHashMap<String,List<CakeOrder>>();
			for(CakeOrder ord : cakeOrderList)
			{
				if(!result.containsKey(ord.getCakeType()))
					result.put(ord.getCakeType(),new ArrayList<CakeOrder>());
				List<CakeOrder> temp = result.get(ord.getCakeType());
				temp.add(ord);
				result.put(ord.getCakeType(),temp);
			}
			return result;
		}
	}
	
	public Map<String,Integer> countTotalCakeOrderForEachStatus() throws InvalidCakeOrderException{
		if(cakeOrderList.size() == 0)
			throw new InvalidCakeOrderException("List is empty");
		else
		{
			Map<String,Integer> result = new LinkedHashMap<String,Integer>();
			for(CakeOrder ord : cakeOrderList)
			{
				if(!result.containsKey(ord.getStatus()))
					result.put(ord.getStatus(),1);
				else
				{
					int temp = result.get(ord.getStatus());
					result.put(ord.getStatus(),temp+1);
				}
			}
			return result;
		}
	}
}


