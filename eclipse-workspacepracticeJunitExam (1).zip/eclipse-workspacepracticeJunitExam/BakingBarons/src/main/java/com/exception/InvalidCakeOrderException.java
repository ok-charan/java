package com.exception;

public class InvalidCakeOrderException extends Exception {

	public InvalidCakeOrderException(String message) {
		super(message);
	}

}
